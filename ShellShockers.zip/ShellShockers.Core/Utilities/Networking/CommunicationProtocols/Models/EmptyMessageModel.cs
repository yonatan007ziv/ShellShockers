﻿namespace ShellShockers.Core.Utilities.Networking.CommunicationProtocols.Models;

public class EmptyMessageModel
{
}