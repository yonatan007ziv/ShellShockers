﻿namespace ShellShockers.Client.GameComponents.WorldComponents.Weapons;

internal enum Weapon
{
	None,
	Pistol,
	Rifle,
	Sniper,
}