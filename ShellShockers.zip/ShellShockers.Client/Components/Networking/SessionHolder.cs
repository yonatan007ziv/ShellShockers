﻿namespace ShellShockers.Client.Components.Networking;

internal class SessionHolder
{
	public static string Username { get; set; } = "";
	public static string AuthenticationToken { get; set; } = "";
}